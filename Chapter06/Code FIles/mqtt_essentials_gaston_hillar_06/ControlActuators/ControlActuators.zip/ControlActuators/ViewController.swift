// Book: MQTT Essentials
// Chapter 6: Interact with Actuators in Swift
// Author: Gaston C. Hillar - Twitter.com/gastonhillar
// Publisher: Packt Publishing Ltd. - http://www.packtpub.com

import UIKit
import CocoaMQTT

class ViewController: UIViewController, CocoaMQTTDelegate {
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var motorSwitch: UISwitch!

    @IBAction func motorSwitchChanged(_ sender: UISwitch) {
        let messagePayload = sender.isOn ? type(of: self).turnOnCommand : type(of: self).turnOffCommand
        mqttClient.publish(type(of: self).motor01CommandTopic, withString: messagePayload, qos: CocoaMQTTQOS.qos0, retained: false, dup: false)
    }

    static let motor01CommandTopic = "commands/boards/inteledison01/actuators/motor01"
    static let motor01StatusTopic = "status/boards/inteledison01"
    static let turnOnCommand = "TURN ON"
    static let turnOffCommand = "TURN OFF"
    
    var mqttClient: CocoaMQTT!
    
    func configureMQTTAndConnect() {
        let clientID = "iOSMotorControl-" + String(ProcessInfo().processIdentifier)
        // Replace with the host name for the MQTT Server
        let host = "localhost"
        // Replace with the port number for MQTT over TCP (without TLS)
        let port = UInt16(1883)
        mqttClient = CocoaMQTT(clientID: clientID, host: host, port: port)
        mqttClient.username = ""
        mqttClient.password = ""
        mqttClient.keepAlive = 60
        mqttClient.delegate = self
        mqttClient.connect()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        configureMQTTAndConnect()
    }

    func mqtt(_ mqtt: CocoaMQTT, didConnect host: String, port: Int) {
        // Connection established with the MQTT Server
        print("Connected with MQTT Server \(host):\(port)")
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didConnectAck ack: CocoaMQTTConnAck) {
        // Connection acknowledged
        print("Connection acknowledged \(ack)，rawValue: \(ack.rawValue)")
        if ack == .accept {
            // Subscribe to the motor01StatusTopic topic with QoS 0
            mqtt.subscribe(type(of: self).motor01StatusTopic, qos: CocoaMQTTQOS.qos0)
        }
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didPublishMessage message: CocoaMQTTMessage, id: UInt16) {
        print("Message published to topic \(message.topic) with payload \(message.string!)")
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didPublishAck id: UInt16) {
        print("Publish acknowledged with id: \(id)")
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didReceiveMessage message: CocoaMQTTMessage, id: UInt16 ) {
        print("Message received in topic \(message.topic) with payload \(message.string!)")
        if (message.topic == type(of: self).motor01StatusTopic) {
            statusLabel.text = "\(message.string!)"
        }
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didSubscribeTopic topic: String) {
        print("Subscribed to \(topic)")
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didUnsubscribeTopic topic: String) {
        print("Unsubscribed from \(topic)")
    }
    
    func mqttDidPing(_ mqtt: CocoaMQTT) {
    }
    
    func mqttDidReceivePong(_ mqtt: CocoaMQTT) {
    }
    
    func mqttDidDisconnect(_ mqtt: CocoaMQTT, withError err: Error?) {
        print("Disconnected from the MQTT Server")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
